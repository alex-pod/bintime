-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 29, 2018 at 09:33 AM
-- Server version: 5.6.35
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bintime`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `postcode` varchar(64) NOT NULL,
  `country_code` varchar(64) NOT NULL,
  `city` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `house_number` varchar(64) NOT NULL,
  `apartment_number` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `postcode`, `country_code`, `city`, `street`, `house_number`, `apartment_number`) VALUES
(1, '42421', 'UA', 'Lorem', 'Ipsum', '12/1', '33A'),
(2, '90007', 'US', 'Los Angeles', 'Figueroa', '2735', 'S'),
(3, '1231', 'AO', 'Test', 'Test', '32', '12B'),
(4, '878444', 'AF', 'Test', 'Test', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `auth_key` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `gender` varchar(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `login`, `password_hash`, `auth_key`, `name`, `surname`, `gender`, `created_at`) VALUES
(1, 'alex', '$2y$13$aoidGkqjsDCyELHRWq7APuFxnAR7xTNHriI4ucQMjVyYlyO0tarxe', 'yluRrBh9kI8-_Kfoor3Yd2zQaytuAhMA', 'Александр', 'admin', '1', '2018-01-27 09:38:20'),
(20, 'new3', '$2y$13$ocJzt6UPGuSETM7fUdnGOu6C31.V2D3B5pUDFQ7hbVdGVZ.VWZbFy', 'cmtZFUfFVK4XdfDPZUyu2CellfTUtO_V', 'Test', 'Test', '2', '2018-01-27 09:48:20'),
(21, 'testy', '$2y$13$8py3b7ujmbQxIcZpNdo.Bul4HBs3rGLok0pZcpEjS1vmh/mdrvN4m', 'kUc4USC43Kqyko1yzThsd_Ruxw30-hFW', 'Another one', 'Test', '1', '2018-01-28 20:33:13');

-- --------------------------------------------------------

--
-- Table structure for table `user_has_address`
--

CREATE TABLE `user_has_address` (
  `user_id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_has_address`
--

INSERT INTO `user_has_address` (`user_id`, `address_id`) VALUES
(18, 1),
(18, 2),
(18, 3),
(17, 2),
(20, 1),
(20, 3),
(21, 4),
(1, 2),
(1, 3),
(1, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
